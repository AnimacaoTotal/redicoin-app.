
import React from 'react';
import { ShoppingCartIcon, ThumbsUpIcon, CertificateIcon, DaoIcon, CheckCircleIcon, RocketLaunchIcon, LockClosedIcon, ChartBarIcon as ChartBarIconSolid } from './icons';

const InfoCard: React.FC<{icon: React.ComponentType<{className?: string}>, title: string, children: React.ReactNode}> = ({ icon: Icon, title, children }) => (
    <div className="p-4 bg-brand-surface rounded-xl flex flex-col items-center text-center">
        <div className="p-3 bg-brand-bg-light rounded-full mb-3">
            <Icon className="w-6 h-6 text-brand-red" />
        </div>
        <h3 className="font-bold text-lg text-brand-text mb-2">{title}</h3>
        <p className="text-sm text-brand-text-secondary">{children}</p>
    </div>
);


export const InfoSection: React.FC = () => {
    return (
        <div className="p-6 sm:p-8 bg-brand-bg-light rounded-2xl shadow-lg">
            <h2 className="text-2xl sm:text-3xl font-bold text-center text-brand-text mb-2">O Conceito: Lastro em Reputação Digital (LRD)</h2>
            <p className="text-center max-w-4xl mx-auto text-brand-text-secondary mb-8">
                A Redicoin é uma criptomoeda lastreada em reputação digital verificada, um ativo intangível de crescente valor. O lastro não se baseia em um ativo físico ou financeiro, mas sim em um índice de reputação auditável e dinâmico.
            </p>

            <div className="space-y-10">
                <div>
                    <h3 className="text-xl font-bold text-center text-brand-text mb-6">Como sua Reputação é Calculada?</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                       <InfoCard icon={ShoppingCartIcon} title="Histórico de Transações">
                            Reputação em marketplaces, plataformas de freelancers e aplicativos.
                       </InfoCard>
                       <InfoCard icon={ThumbsUpIcon} title="Engajamento Social">
                            Métricas de autoridade e engajamento em redes como LinkedIn, X e outras.
                       </InfoCard>
                       <InfoCard icon={CertificateIcon} title="Validações de Competências">
                            Certificações profissionais, cursos concluídos e endossos de competências.
                       </InfoCard>
                       <InfoCard icon={DaoIcon} title="Governança e DAOs">
                            Histórico de votações, propostas e contribuições em Organizações Autônomas Descentralizadas.
                       </InfoCard>
                    </div>
                </div>

                <div>
                    <h3 className="text-xl font-bold text-center text-brand-text mb-6">Por que Redicoin é Inovador?</h3>
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                       <InfoCard icon={RocketLaunchIcon} title="Ativo Inexplorado">
                            Transforma a reputação, um ativo valioso, em um ativo financeiro líquido.
                       </InfoCard>
                       <InfoCard icon={CheckCircleIcon} title="Democratiza o Crédito">
                            Permite usar tokens de reputação como garantia para acesso a serviços financeiros.
                       </InfoCard>
                       <InfoCard icon={ChartBarIconSolid} title="Novas Monetizações">
                            Criadores e profissionais podem monetizar diretamente seu capital social.
                       </InfoCard>
                       <InfoCard icon={LockClosedIcon} title="Incentivo à Boa Conduta">
                            A monetização da reputação incentiva a honestidade e a transparência no ecossistema digital.
                       </InfoCard>
                    </div>
                </div>
            </div>
        </div>
    );
};
