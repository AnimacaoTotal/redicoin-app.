
import React from 'react';

interface DashboardCardProps {
    balance: number;
}

export const DashboardCard: React.FC<DashboardCardProps> = ({ balance }) => {
    return (
        <div className="relative p-6 sm:p-8 bg-gradient-to-br from-brand-red to-red-800 rounded-2xl shadow-2xl overflow-hidden">
            <div className="absolute inset-0 bg-black/20"></div>
            <div className="relative z-10">
                <p className="text-lg font-medium text-red-100">Saldo Total de Reputação</p>
                <div className="flex items-baseline mt-2">
                    <h2 className="text-5xl font-extrabold text-white tracking-tight">
                        {balance.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </h2>
                    <span className="ml-2 text-2xl font-medium text-red-200">RC</span>
                </div>
                <p className="mt-1 text-red-200">Seu valor no ecossistema digital.</p>
                <div className="mt-6 flex space-x-4">
                    <button className="bg-white/20 hover:bg-white/30 text-white font-semibold py-2 px-5 rounded-full backdrop-blur-sm transition-all duration-300">
                        Apostar
                    </button>
                    <button className="bg-white/20 hover:bg-white/30 text-white font-semibold py-2 px-5 rounded-full backdrop-blur-sm transition-all duration-300">
                        Transferir
                    </button>
                </div>
            </div>
        </div>
    );
};
