import React from 'react';
// FIX: Import ChartBarIcon to resolve the 'Cannot find name' error.
import { EyeIcon, LinkedInIcon, LockClosedIcon, RocketLaunchIcon, TargetIcon, UserCircleIcon, UsersIcon, XIcon, ChartBarIcon } from './icons';

const ValueCard: React.FC<{ icon: React.ComponentType<{ className?: string }>; title: string; children: React.ReactNode }> = ({ icon: Icon, title, children }) => (
    <div className="p-6 bg-brand-surface rounded-xl text-center transition-transform transform hover:-translate-y-1">
        <div className="inline-block p-4 bg-brand-bg-dark rounded-full mb-4 border border-brand-surface">
            <Icon className="w-8 h-8 text-brand-red" />
        </div>
        <h3 className="font-bold text-xl text-brand-text mb-2">{title}</h3>
        <p className="text-sm text-brand-text-secondary">{children}</p>
    </div>
);

const TeamMemberCard: React.FC<{ name: string; title: string; children: React.ReactNode }> = ({ name, title, children }) => (
    <div className="p-6 bg-brand-surface rounded-xl text-center">
        <UserCircleIcon className="w-24 h-24 text-brand-text-secondary mx-auto mb-4" />
        <h4 className="font-bold text-lg text-brand-text">{name}</h4>
        <p className="text-sm text-brand-red font-medium mb-3">{title}</p>
        <p className="text-xs text-brand-text-secondary mb-4">{children}</p>
        <div className="flex justify-center space-x-4">
            <a href="#" className="text-brand-text-secondary hover:text-brand-text"><XIcon className="w-5 h-5"/></a>
            <a href="#" className="text-brand-text-secondary hover:text-brand-text"><LinkedInIcon className="w-5 h-5"/></a>
        </div>
    </div>
);


export const Sobre: React.FC = () => {
    return (
        <div className="space-y-12 sm:space-y-16">
            <div className="text-center">
                <h1 className="text-4xl sm:text-5xl font-extrabold text-brand-text tracking-tight mb-4">Sobre a Redicoin</h1>
                <p className="max-w-3xl mx-auto text-lg text-brand-text-secondary">
                    Construindo a próxima geração da economia digital, onde a confiança é o ativo mais valioso.
                </p>
            </div>

            <div className="p-8 bg-brand-bg-light rounded-2xl shadow-lg">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                    <div className="text-center md:text-left">
                         <h2 className="text-3xl font-bold text-brand-text mb-4 flex items-center justify-center md:justify-start">
                            <TargetIcon className="w-8 h-8 mr-3 text-brand-red"/>
                            Nossa Missão
                        </h2>
                        <p className="text-brand-text-secondary">
                            Democratizar o acesso a serviços financeiros e oportunidades, permitindo que qualquer indivíduo no mundo possa monetizar seu ativo mais fundamental: a reputação digital. Criamos um sistema transparente que transforma a confiança em um ativo tangível e líquido.
                        </p>
                    </div>
                     <div className="text-center md:text-left">
                        <h2 className="text-3xl font-bold text-brand-text mb-4 flex items-center justify-center md:justify-start">
                             <EyeIcon className="w-8 h-8 mr-3 text-brand-red"/>
                             Nossa Visão
                        </h2>
                        <p className="text-brand-text-secondary">
                            Ser o pilar de um novo ecossistema financeiro global, onde a reputação verificada se torna uma classe de ativo universalmente reconhecida. Almejamos um futuro onde o valor de um indivíduo é medido por sua confiabilidade e contribuições, não apenas por seu capital.
                        </p>
                    </div>
                </div>
            </div>

            <div className="text-center">
                <h2 className="text-3xl font-bold text-brand-text mb-6">Nossos Valores</h2>
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <ValueCard icon={UsersIcon} title="Comunidade">
                        Acreditamos que a força da Redicoin reside em nossa comunidade. Construímos juntos, crescemos juntos.
                    </ValueCard>
                    <ValueCard icon={LockClosedIcon} title="Segurança">
                        A proteção dos dados e da reputação de nossos usuários é nossa prioridade máxima, utilizando criptografia de ponta.
                    </ValueCard>
                    <ValueCard icon={RocketLaunchIcon} title="Inovação">
                        Estamos constantemente explorando novas fronteiras para redefinir o que é possível na economia digital.
                    </ValueCard>
                    <ValueCard icon={ChartBarIcon} title="Transparência">
                        Operamos com clareza e honestidade. O algoritmo de reputação é auditável e as regras são claras para todos.
                    </ValueCard>
                 </div>
            </div>

            <div className="text-center">
                <h2 className="text-3xl font-bold text-brand-text mb-8">Nossa Equipe</h2>
                <p className="max-w-2xl mx-auto text-brand-text-secondary mb-8">
                    Conheça o criador por trás da Redicoin, um desenvolvedor apaixonado por construir um futuro financeiro mais justo e transparente.
                </p>
                <div className="flex justify-center">
                    <div className="max-w-sm">
                        <TeamMemberCard name="Rafael P. Mourão" title="Fundador & Criador">
                            Idealizador e único desenvolvedor do projeto Redicoin, focado em transformar a reputação digital em um ativo valioso e acessível.
                        </TeamMemberCard>
                    </div>
                </div>
            </div>
        </div>
    );
};