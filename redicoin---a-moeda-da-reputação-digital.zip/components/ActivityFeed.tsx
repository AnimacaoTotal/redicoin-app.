
import React from 'react';
import type { Activity } from '../types';
import { ClockIcon } from './icons';

interface ActivityFeedProps {
    activities: Activity[];
}

export const ActivityFeed: React.FC<ActivityFeedProps> = ({ activities }) => {
    return (
        <div className="p-4 sm:p-6 bg-brand-bg-light rounded-2xl shadow-lg h-full">
            <h2 className="text-xl font-bold mb-4 text-brand-text flex items-center">
                <ClockIcon className="w-6 h-6 mr-2 text-brand-red"/>
                Atividade Recente
            </h2>
            <div className="space-y-4">
                {activities.length > 0 ? (
                    activities.map((activity) => (
                        <div key={activity.id} className="flex items-center space-x-4">
                            <div className={`p-2 rounded-full ${activity.type === 'gain' ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                                <activity.icon className={`w-5 h-5 ${activity.type === 'gain' ? 'text-green-400' : 'text-red-400'}`} />
                            </div>
                            <div className="flex-1">
                                <p className="text-sm font-medium text-brand-text">{activity.description}</p>
                                <p className="text-xs text-brand-text-secondary">{activity.timestamp}</p>
                            </div>
                            <p className={`text-sm font-bold ${activity.type === 'gain' ? 'text-green-400' : 'text-red-400'}`}>
                                {activity.type === 'gain' ? '+' : '-'} {activity.amount.toFixed(2)} RC
                            </p>
                        </div>
                    ))
                ) : (
                    <p className="text-center text-brand-text-secondary py-8">Nenhuma atividade recente.</p>
                )}
            </div>
        </div>
    );
};
