import React from 'react';
import { DashboardCard } from './DashboardCard';
import { ReputationChart } from './ReputationChart';
import { ActivityFeed } from './ActivityFeed';
import { InfoSection } from './InfoSection';
import { CoinIcon, ChartBarIcon, DocumentTextIcon, UsersIcon } from './icons';
import type { ChartData, Activity, Stats } from '../types';

interface PainelProps {
    balance: number;
    chartData: ChartData[];
    activities: Activity[];
    stats: Stats;
}

export const Painel: React.FC<PainelProps> = ({ balance, chartData, activities, stats }) => {
    return (
        <>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <DashboardCard balance={balance} />
                    <div className="p-4 sm:p-6 bg-brand-bg-light rounded-2xl shadow-lg">
                        <h2 className="text-xl font-bold mb-4 text-brand-text flex items-center">
                            <ChartBarIcon className="w-6 h-6 mr-2 text-brand-red" />
                            Histórico de Reputação
                        </h2>
                        <ReputationChart data={chartData} />
                    </div>
                </div>
                <div className="lg:col-span-1 space-y-6">
                    <ActivityFeed activities={activities} />
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
                <div className="p-4 bg-brand-bg-light rounded-2xl shadow-lg flex items-center space-x-4">
                    <div className="p-3 bg-brand-surface rounded-full">
                        <CoinIcon className="w-6 h-6 text-brand-red" />
                    </div>
                    <div>
                        <p className="text-sm text-brand-text-secondary">Capitalização de Mercado</p>
                        <p className="text-lg font-bold">{stats.marketCap}</p>
                    </div>
                </div>
                <div className="p-4 bg-brand-bg-light rounded-2xl shadow-lg flex items-center space-x-4">
                    <div className="p-3 bg-brand-surface rounded-full">
                        <UsersIcon className="w-6 h-6 text-brand-red" />
                    </div>
                    <div>
                        <p className="text-sm text-brand-text-secondary">Detentores</p>
                        <p className="text-lg font-bold">{stats.holders}</p>
                    </div>
                </div>
                <div className="p-4 bg-brand-bg-light rounded-2xl shadow-lg flex items-center space-x-4">
                    <div className="p-3 bg-brand-surface rounded-full">
                        <DocumentTextIcon className="w-6 h-6 text-brand-red" />
                    </div>
                    <div>
                        <p className="text-sm text-brand-text-secondary">Transações (24h)</p>
                        <p className="text-lg font-bold">{stats.transactions}</p>
                    </div>
                </div>
                <div className="p-4 bg-brand-bg-light rounded-2xl shadow-lg flex items-center space-x-4">
                    <div className="p-3 bg-brand-surface rounded-full">
                        <ChartBarIcon className="w-6 h-6 text-green-500" />
                    </div>
                    <div>
                        <p className="text-sm text-brand-text-secondary">Variação (24h)</p>
                        <p className="text-lg font-bold text-green-500">+{stats.change}%</p>
                    </div>
                </div>
            </div>
            <div className="mt-8">
                <InfoSection />
            </div>
        </>
    );
};