
import { useState, useEffect, useCallback } from 'react';
import type { Activity, ChartData, Stats } from '../types';
import { UpArrowIcon, DownArrowIcon, CertificateIcon, DaoIcon, ShoppingCartIcon, ThumbsUpIcon } from '../components/icons';

const initialBalance = 1250.75;
const initialChartData: ChartData[] = [
    { date: 'Jan', value: 800 },
    { date: 'Fev', value: 950 },
    { date: 'Mar', value: 900 },
    { date: 'Abr', value: 1100 },
    { date: 'Mai', value: 1050 },
    { date: 'Jun', value: 1250.75 },
];

const mockActivities: Omit<Activity, 'id' | 'timestamp' | 'amount'>[] = [
    { description: "Avaliação 5 estrelas no Marketplace", type: 'gain', icon: ShoppingCartIcon },
    { description: "Endosso de competência em 'React'", type: 'gain', icon: ThumbsUpIcon },
    { description: "Certificado 'Cloud' verificado", type: 'gain', icon: CertificateIcon },
    { description: "Proposta de governança aprovada em DAO", type: 'gain', icon: DaoIcon },
    { description: "Post com alto engajamento em rede social", type: 'gain', icon: UpArrowIcon },
    { description: "Avaliação negativa em transação", type: 'loss', icon: DownArrowIcon },
    { description: "Comentário marcado como 'não útil'", type: 'loss', icon: DownArrowIcon },
];

const formatNumber = (num: number) => {
    if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(2) + 'B';
    if (num >= 1_000_000) return (num / 1_000_000).toFixed(2) + 'M';
    if (num >= 1_000) return (num / 1_000).toFixed(1) + 'K';
    return num.toString();
};

export const useMockData = () => {
    const [balance, setBalance] = useState(initialBalance);
    const [chartData, setChartData] = useState<ChartData[]>(initialChartData);
    const [activities, setActivities] = useState<Activity[]>([]);
    const [stats, setStats] = useState<Stats>({
        marketCap: '$' + formatNumber(18_450_987_123),
        holders: formatNumber(1_234_567),
        transactions: formatNumber(456_789),
        change: 2.15,
    });
    
    const generateNewActivity = useCallback(() => {
        const randomActivityTemplate = mockActivities[Math.floor(Math.random() * mockActivities.length)];
        const amount = parseFloat((Math.random() * 10 + 1).toFixed(2));
        
        const newActivity: Activity = {
            ...randomActivityTemplate,
            id: Date.now(),
            amount: amount,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };

        setActivities(prev => [newActivity, ...prev.slice(0, 5)]);

        setBalance(prevBalance => {
            const newBalance = newActivity.type === 'gain' ? prevBalance + amount : prevBalance - amount;
            
            setChartData(prevChartData => {
                const newDate = new Date();
                const newDateLabel = `${newDate.getHours()}:${String(newDate.getMinutes()).padStart(2, '0')}`;
                
                const newPoint = { date: newDateLabel, value: parseFloat(newBalance.toFixed(2)) };
                
                // Keep the chart data from becoming too large
                const updatedChartData = [...prevChartData, newPoint];
                return updatedChartData.length > 12 ? updatedChartData.slice(updatedChartData.length - 12) : updatedChartData;
            });

            return newBalance;
        });

    }, []);

    useEffect(() => {
        // eslint-disable-next-line react-hooks/exhaustive-deps
        generateNewActivity(); // Initial activity
        const interval = setInterval(generateNewActivity, 5000);
        return () => clearInterval(interval);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return { balance, chartData, activities, stats };
};
