import React, { useState } from 'react';
import { Header } from './components/Header';
import { useMockData } from './hooks/useMockData';
import type { View } from './types';
import { Painel } from './components/Painel';
import { Reputacao } from './components/Reputacao';
import { Sobre } from './components/Sobre';
import { WalletConnectModal } from './components/WalletConnectModal';

const App: React.FC = () => {
  const { balance, chartData, activities, stats } = useMockData();
  const [view, setView] = useState<View>('painel');
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);

  const handleConnectWallet = () => {
    // Simula a conexão com uma carteira e gera um endereço falso
    const mockAddress = "0x" + [...Array(40)].map(() => Math.floor(Math.random() * 16).toString(16)).join('');
    setWalletAddress(mockAddress);
    setIsWalletModalOpen(false); // Fecha o modal após a "conexão"
  };

  const handleDisconnectWallet = () => {
    setWalletAddress(null);
  };


  const renderContent = () => {
    switch (view) {
      case 'painel':
        return <Painel {...{ balance, chartData, activities, stats }} />;
      case 'reputacao':
        return <Reputacao />;
      case 'sobre':
        return <Sobre />;
      default:
        return <Painel {...{ balance, chartData, activities, stats }} />;
    }
  };

  return (
    <div className="min-h-screen bg-brand-bg-dark text-brand-text">
      <Header 
        currentView={view} 
        onNavigate={setView}
        walletAddress={walletAddress}
        onConnectClick={() => setIsWalletModalOpen(true)}
        onDisconnectClick={handleDisconnectWallet}
      />
      <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {renderContent()}
      </main>
      <footer className="text-center p-6 text-brand-text-secondary text-sm">
        <p>&copy; {new Date().getFullYear()} Redicoin. Todos os direitos reservados. Um projeto conceitual.</p>
      </footer>
      {isWalletModalOpen && (
        <WalletConnectModal 
          onClose={() => setIsWalletModalOpen(false)}
          onConnect={handleConnectWallet}
        />
      )}
    </div>
  );
};

export default App;