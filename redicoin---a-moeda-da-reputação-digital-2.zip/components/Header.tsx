import React from 'react';
import { CoinIcon, WalletIcon } from './icons';
import type { View } from '../types';

interface HeaderProps {
    currentView: View;
    onNavigate: (view: View) => void;
    walletAddress: string | null;
    onConnectClick: () => void;
    onDisconnectClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentView, onNavigate, walletAddress, onConnectClick, onDisconnectClick }) => {
  
  const navLinkClasses = (view: View) => 
    `text-brand-text-secondary hover:text-brand-text transition-colors px-3 py-2 rounded-md text-sm font-medium cursor-pointer ${
      currentView === view ? 'text-brand-text bg-brand-surface' : ''
    }`;

  const truncateAddress = (address: string) => `${address.slice(0, 6)}...${address.slice(-4)}`;

  return (
    <header className="bg-brand-bg-light/80 backdrop-blur-sm sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <CoinIcon className="h-8 w-8 text-brand-red" />
            <h1 className="ml-3 text-2xl font-bold text-brand-text tracking-tight">
              Redicoin
            </h1>
          </div>
          <nav className="hidden md:flex items-center space-x-4">
            <button onClick={() => onNavigate('painel')} className={navLinkClasses('painel')}>Painel</button>
            <button onClick={() => onNavigate('reputacao')} className={navLinkClasses('reputacao')}>Reputação</button>
            <button onClick={() => onNavigate('sobre')} className={navLinkClasses('sobre')}>Sobre</button>
            {walletAddress ? (
               <button 
                onClick={onDisconnectClick}
                className="bg-brand-surface hover:bg-opacity-80 text-brand-text font-mono text-sm py-2 px-4 rounded-full transition-all duration-300 flex items-center space-x-2"
               >
                <WalletIcon className="w-5 h-5 text-green-400" />
                <span>{truncateAddress(walletAddress)}</span>
              </button>
            ) : (
              <button 
                onClick={onConnectClick}
                className="bg-brand-red hover:bg-brand-red-dark text-white font-bold py-2 px-4 rounded-full transition-all duration-300 transform hover:scale-105 flex items-center space-x-2"
              >
                <WalletIcon className="w-5 h-5" />
                <span>Conectar Carteira</span>
              </button>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};