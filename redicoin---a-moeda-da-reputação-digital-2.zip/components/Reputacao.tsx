import React from 'react';
import { ShoppingCartIcon, ThumbsUpIcon, CertificateIcon, DaoIcon, LinkIcon, LinkedInIcon, LightBulbIcon, GitHubIcon } from './icons';

interface ReputationFactorProps {
    icon: React.ComponentType<{ className?: string }>;
    title: string;
    percentage: number;
    color: string;
}

const ReputationFactor: React.FC<ReputationFactorProps> = ({ icon: Icon, title, percentage, color }) => (
    <div className="p-4 bg-brand-surface rounded-lg">
        <div className="flex items-center mb-2">
            <Icon className={`w-5 h-5 mr-3 ${color}`} />
            <span className="text-brand-text font-medium">{title}</span>
            <span className="ml-auto text-sm font-bold text-brand-text">{percentage}%</span>
        </div>
        <div className="w-full bg-brand-bg-dark rounded-full h-2">
            <div className={`${color === 'text-brand-red' ? 'bg-brand-red' : color === 'text-blue-400' ? 'bg-blue-400' : color === 'text-purple-400' ? 'bg-purple-400' : 'bg-amber-400'} h-2 rounded-full`} style={{ width: `${percentage}%` }}></div>
        </div>
    </div>
);

interface ConnectedSourceProps {
    icon: React.ComponentType<{ className?: string }>;
    name: string;
    status: 'connected' | 'disconnected';
}

const ConnectedSource: React.FC<ConnectedSourceProps> = ({ icon: Icon, name, status }) => (
    <div className="flex items-center p-4 bg-brand-surface rounded-lg">
        <Icon className="w-6 h-6 mr-4 text-brand-text-secondary" />
        <span className="text-brand-text font-medium flex-1">{name}</span>
        {status === 'connected' ? (
             <button className="text-xs font-semibold text-green-400 bg-green-500/20 py-1 px-3 rounded-full hover:bg-green-500/30 transition-colors">
                Gerenciar
            </button>
        ) : (
            <button className="text-xs font-semibold text-brand-text-secondary bg-brand-surface border border-brand-text-secondary/50 py-1 px-3 rounded-full hover:bg-brand-text-secondary/20 transition-colors">
                Conectar
            </button>
        )}
    </div>
);

const ImprovementTip: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <div className="flex items-start p-4 bg-brand-surface rounded-lg space-x-3">
        <div className="flex-shrink-0">
            <LightBulbIcon className="w-5 h-5 text-amber-400 mt-0.5" />
        </div>
        <p className="text-sm text-brand-text-secondary">{children}</p>
    </div>
);

export const Reputacao: React.FC = () => {
    const reputationFactors: ReputationFactorProps[] = [
        { icon: ShoppingCartIcon, title: "Histórico de Transações", percentage: 45, color: 'text-brand-red' },
        { icon: ThumbsUpIcon, title: "Engajamento Social", percentage: 25, color: 'text-blue-400' },
        { icon: CertificateIcon, title: "Validações de Competências", percentage: 18, color: 'text-purple-400' },
        { icon: DaoIcon, title: "Governança e DAOs", percentage: 12, color: 'text-amber-400' },
    ];
    
    const connectedSources: ConnectedSourceProps[] = [
        { icon: LinkedInIcon, name: "LinkedIn", status: 'connected' },
        { icon: GitHubIcon, name: "GitHub", status: 'connected' },
        { icon: ShoppingCartIcon, name: "Marketplace XYZ", status: 'disconnected' },
    ];

    return (
        <div className="space-y-10">
            <div className="text-center">
                <h1 className="text-4xl sm:text-5xl font-extrabold text-brand-text tracking-tight mb-4">Gerencie sua Reputação</h1>
                <p className="max-w-3xl mx-auto text-lg text-brand-text-secondary">
                    Aqui você pode ver a composição da sua pontuação, conectar novas fontes de dados e descobrir como melhorar sua reputação digital.
                </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                <div className="lg:col-span-3 p-6 bg-brand-bg-light rounded-2xl shadow-lg">
                    <h2 className="text-xl font-bold text-brand-text mb-6">Composição da Pontuação</h2>
                    <div className="space-y-4">
                        {reputationFactors.map(factor => <ReputationFactor key={factor.title} {...factor} />)}
                    </div>
                </div>

                <div className="lg:col-span-2 p-6 bg-brand-bg-light rounded-2xl shadow-lg">
                    <h2 className="text-xl font-bold text-brand-text mb-6 flex items-center">
                        <LinkIcon className="w-5 h-5 mr-2" />
                        Fontes Conectadas
                    </h2>
                     <div className="space-y-4">
                        {connectedSources.map(source => <ConnectedSource key={source.name} {...source} />)}
                    </div>
                </div>
            </div>

            <div>
                <h2 className="text-2xl font-bold text-brand-text text-center mb-6">Como Melhorar sua Pontuação</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <ImprovementTip>
                        <strong>Complete seu perfil</strong> em plataformas conectadas. Perfis completos tendem a gerar mais confiança e, consequentemente, mais reputação.
                    </ImprovementTip>
                     <ImprovementTip>
                        <strong>Participe ativamente em DAOs.</strong> Votar em propostas e contribuir com discussões aumenta sua pontuação de governança.
                    </ImprovementTip>
                     <ImprovementTip>
                        <strong>Solicite e forneça avaliações</strong> após transações em marketplaces. Feedbacks positivos são uma fonte poderosa de reputação.
                    </ImprovementTip>
                </div>
            </div>
        </div>
    );
};
