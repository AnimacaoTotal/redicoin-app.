import React, { useState } from 'react';
import { CloseIcon, SpinnerIcon, WalletIcon } from './icons';

interface WalletConnectModalProps {
  onClose: () => void;
  onConnect: () => void;
}

export const WalletConnectModal: React.FC<WalletConnectModalProps> = ({ onClose, onConnect }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleConnectClick = () => {
    setIsLoading(true);
    // Simula uma demora na conexão
    setTimeout(() => {
      onConnect();
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="relative bg-brand-bg-light w-full max-w-md p-6 sm:p-8 rounded-2xl shadow-2xl border border-brand-surface animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-brand-text-secondary hover:text-brand-text transition-colors"
          aria-label="Fechar modal"
        >
          <CloseIcon className="w-6 h-6" />
        </button>

        <div className="text-center">
            <div className="mx-auto mb-4 inline-block p-4 bg-brand-surface rounded-full">
                <WalletIcon className="w-10 h-10 text-brand-red" />
            </div>
            <h2 className="text-2xl font-bold text-brand-text mb-2">Conectar sua Carteira</h2>
            <p className="text-brand-text-secondary mb-6">Para interagir com o ecossistema Redicoin, conecte sua carteira digital. Isso permite o acesso ao seu saldo e atividades.</p>

            <button
                onClick={handleConnectClick}
                disabled={isLoading}
                className="w-full bg-brand-red hover:bg-brand-red-dark text-white font-bold py-3 px-4 rounded-full transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
                {isLoading ? (
                    <>
                        <SpinnerIcon className="w-5 h-5" />
                        <span>Conectando...</span>
                    </>
                ) : (
                    <span>Conectar Agora</span>
                )}
            </button>
        </div>
      </div>
    </div>
  );
};
